#include <iostream> 
#include <fstream> 
#include <sstream>
#include <string> 
using namespace std; 

ifstream fin("a.txt");
ofstream fout("b.txt"); 
string key = "ABDDCAAEEE";

int main(){
    int N = 10; 
    char ans[N]; 
    int c = 0; 
    for (int i=0; i<N; i++){
        fin >> ans[i]; 
        //if (ans[i]==key.at(i)) c++; 
        if (ans[i]==key[i]) c++; 
    }
    fout << c << endl; 
    fout.close(); 
    fin.close(); 
}