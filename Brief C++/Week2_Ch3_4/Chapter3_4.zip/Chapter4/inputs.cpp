#include <iostream> 
#include <iomanip> 
#include <string> 
using namespace std; 

int main(){
    char a; 
    cout << "Single Character: " << endl;
    cout << "Enter a character: " ; 
    cin.get(a); 
    cout << "The letter: " << a << endl; 
    cout << "Tokens: " << endl; 
    char b;  float d; string xx;  
    cout << "Enter c, f, str: " ; 
    cin >> b >> d >> xx ; 
    cout << b << endl; 
    cout << d << endl; 
    cout << xx << endl; 
    cout << "Lines: " << endl;
    string line = ""; 
    getline(cin, line); // feedthrough; 
    cout << "Enter a line: " << endl; 
    getline(cin, line); 
    cout << line << endl; 
    return 0; 
}