#include <iostream> 
#include <string> 
#include <cstdbool> 

using namespace std; 

int main(){
    string a("ABCDEF"); 
    string b("ABCDEF"); 
    string c("ABCD"); 
    string d("abcd"); 
    string e("BBCD");
    string f("abc");  
    string b0 = (a==b) ? "true" : "false"; 
    if (a==b) { cout << "a==b is " << b0 << endl;  }
    else      { cout << "a==b is " << b0 << endl;  }
    if (a==c) { cout << "a==c is " << 1 << endl;  }
    else      { cout << "a==c is " << 0 << endl;  }

    cout << "a.compare(c) = " << a.compare(c) << endl; 
    cout << "d.compare(e) = " << d.compare(e) << endl; 

    string x = "sja;flkjsd";
    string y("dskjf;as"); 
    char cc[] = {'a', 'b', 'd', '\0'}; // not C-style string
    string z(cc); 
    

    cout << x << endl; 
    cout << y << endl; 
    cout << z << endl; 
    z = x; 
    z[0] ='w'; 
    cout << x << endl; 
    cout << z << endl; 
    return 0; 
}