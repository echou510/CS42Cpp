#include <iostream> 
#include <iomanip>
#include <cstdio> 

using namespace std; 

int main(){
    double w = 3.12345678901234567890123456789; 
    cout << "C++: " << endl; 
    cout << right << setw(15) << setprecision(10) <<"w=" << w << endl;
    cout << endl << endl; 
   
    cout << "w+="; 
    cout << left << setw(6) << setprecision(2); 
    cout << w << endl;
    cout << "C: " << endl;
    printf("w*=%.10lf\n", w);  
    return 0;
}