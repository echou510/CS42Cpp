#include <iostream> 
#include <iomanip>
#include <cstdio> 

using namespace std; 

int main(){
    string sss = "012345678901234567890123456789"; 
    cout << "sss.length()=" << sss.length() << endl; 
    cout << "sss.size()=" << sss.size() << endl;
    cout << "sss.find(456)=" << sss.find("456") << endl; 
    cout << "sss.find(9)=" << sss.find('9') << endl; 
    cout << "sss.substr(12, 5)=" << sss.substr(12, 5) << endl;    
    return 0;
}