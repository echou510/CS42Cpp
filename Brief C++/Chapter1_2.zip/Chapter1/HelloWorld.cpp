#include <cstdio>

int main(int argc, char *argv[]){   // public static void main(String[] args)
    printf("Hello World...");
    return 0; 
}