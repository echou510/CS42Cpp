// *************************************************** 
//  Walk program using file I/O
//  This program computes the mileage (rounded to nearest
//  tenth of mile) for each of 4 distances, using input
//  map measurements and map scale.
// ***************************************************

#include <iostream>		// for cout, endl
#include <iomanip>		// for setprecision
#include <fstream>		// for file I/O

using namespace std;

float  RoundToNearestTenth(float);  // declare function
int  main(void)
{
     float     distance1;  	// First map distance
     float     distance2;  	// Second map distance
     float     distance3;  	// Third map distance
     float     distance4;  	// Fourth map distance
     float     scale;            	// Map scale (miles/inch)

     float     totMiles;        	// Total of rounded miles
     float     miles;		// One rounded mileage

     ifstream  inFile;  		// First map distance
     ofstream  outFile;  		// Second map distance

     outFile << fixed << showpoint  // output file format
	      << setprecision(1);

	 // Open the files
     inFile.open("walk.dat");	
     outFile.open("results.dat");

	 // Get data from file
     inFile >>  distance1  >> distance2  >> distance3
            >>  distance4  >> scale;

     totMiles = 0.0;			// Initialize total miles

		// Compute miles for each distance on map


     miles = RoundToNearestTenth( distance1 * scale );

     outFile <<  distance1 << " inches on map is "
	      <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;

     miles = RoundToNearestTenth( distance2 * scale );

     outFile <<  distance2 << " inches on map is "
	      <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;

     miles = RoundToNearestTenth( distance3 * scale );

     outFile <<  distance3 << " inches on map is "
	      <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;


     miles = RoundToNearestTenth( distance4 * scale );

     outFile <<  distance4 << " inches on map is "
	      <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;

     //  Write total miles to output file
     outFile <<  endl << "Total walking mileage is  "  
             <<  totMiles  <<  " miles."  << endl;

     return 0 ;			//  Successful completion
}

float  RoundToNearestTenth (float floatValue){       
     return  float(int(floatValue * 10.0 + 0.5)) / 10.0;
}

