#include  <iostream>
#include  <string>		// for functions length, find, substr

using  namespace  std;

int  main(void){
    string  stateName = "Mississippi";
    cout << stateName.length()     << endl;  		// value 11
    cout << stateName.find("is")   <<  endl;		// value 1
    cout << stateName.substr(0, 4) <<  endl;		// value �Miss�
    cout << stateName.substr(4, 2) <<  endl;		// value �is�
    cout << stateName.substr(9, 5) <<  endl;		// value �pi�
    return 0 ;
}
