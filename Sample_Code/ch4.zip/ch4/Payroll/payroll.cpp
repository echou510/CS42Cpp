// *************************************************** 
//  Payroll program
//  This program computes each employee�s wages and
//  the total company payroll
// ***************************************************

#include <iostream>		// for keyboard/screen I/O
#include <fstream>		// for file I/O

using namespace std;

void  CalcPay (float, float, float&);

const  float  MAX_HOURS = 40.0;  // Maximum normal hours
const  float  OVER_TIME = 1.5;    // Overtime pay factor

int  main(void)
{
     float     payRate;     //  Employee�s pay rate
     float     hours;		//  Hours  worked
     float     wages; 		//  Wages earned
     float     total;		//  Total company payroll
     int       empNum;		//  Employee  ID  number
     ofstream  payFile;		// Company  payroll file

     payFile.open("payfile.dat");	// Open file
     total = 0.0;				// Initialize total
     cout << "Enter employee number: ";  // Prompt

     cin  >> empNum;                     // Read ID number

     while (empNum != 0)             // While not done
     {
	  cout << "Enter pay rate: ";		
	  cin  >> payRate ; 	              // Read pay rate
	  cout << "Enter hours worked: ";
	  cin  >> hours ;                 // and hours worked

	  CalcPay(payRate, hours, wages); // Compute wages

	  total = total + wages;		 // Add to total

	  payFile << empNum << payRate 
                 << hours << wages << endl;

	  cout << "Enter employee number: ";
	  cin  >> empNum;                 // Read ID number 
     }
     cout <<  "Total payroll is  "  
          <<  total  << endl;

     return 0 ;			//  Successful completion
}

void  CalcPay ( /* in */   float   payRate ,
                /* in */   float   hours ,
                /* out */  float&  wages )
//  CalcPay computes wages from the employee�s pay rate
//  and the hours worked, taking overtime into account
{       
     if ( hours  >  MAX_HOURS )
	  wages = (MAX_HOURS * payRate ) +
                 (hours - MAX_HOURS) * payRate * OVER_TIME;
     else
	  wages  =  hours * payRate;
}
