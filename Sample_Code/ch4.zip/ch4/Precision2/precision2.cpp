#include  <iomanip>		          // for setw( )
#include  <iostream>
#include  <string>

using  namespace  std;

int  main(void)
{
    int  myNumber    =  123 ;
    int  yourNumber  =  5 ;

    cout  << setw(10) << "Mine"  
	      << setw(10) << "Yours" << endl; 
    cout  << setw(10) << myNumber
	      << setw(10) << yourNumber << endl;

    return 0;
}
