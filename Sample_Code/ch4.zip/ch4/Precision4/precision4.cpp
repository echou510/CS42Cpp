#include  <iostream>
#include  <string>		// for functions length, find, substr

using  namespace  std;

int  main(void)
{
    string  stateName = "Mississippi";

    cout << stateName.length()     << endl;  
    cout << stateName.find("is")   <<  endl;
    cout << stateName.substr(0, 4) <<  endl;
    cout << stateName.substr(4, 2) <<  endl;
    cout << stateName.substr(9, 5) <<  endl;

    return 0 ;
}
