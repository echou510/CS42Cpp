// *************************************************** 
//  Walk program
//  This program computes the mileage (rounded to nearest
//  tenth of mile) for each of 4 distances, given map
//  measurements on map with scale of 1 in = 0.25 mile
// ***************************************************

#include <iostream>		// for cout, endl
#include <iomanip>		// For setprecision

using namespace std;

float  RoundToNearestTenth( float );  // declare function

const  float  SCALE = 0.25;     // Map scale (mi. per inch)
const  float  DISTANCE1 = 1.5;  // First map distance
const  float  DISTANCE2 = 2.3;  // Second map distance
const  float  DISTANCE3 = 5.9;  // Third map distance
const  float  DISTANCE4 = 4.0;  // Fourth map distance


int  main(void){
     float     totMiles;    // Total of rounded miles
     float     miles;		// One rounded mileage

     cout << fixed << showpoint  // Set output format
	   << setprecision(1);

     totMiles = 0.0;			// Initialize total miles
	// Compute miles for each distance on map

     miles = RoundToNearestTenth( DISTANCE1 * SCALE );

     cout <<  DISTANCE1 << "inches on map is "
	   <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;


     miles = RoundToNearestTenth( DISTANCE2 * SCALE );

     cout <<  DISTANCE2 << " inches on map is "
	   <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;
	// Compute miles for other distances on map


     miles = RoundToNearestTenth( DISTANCE3 * SCALE );

     cout <<  DISTANCE3 << " inches on map is "
	   <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;


     miles = RoundToNearestTenth( DISTANCE4 * SCALE );

     cout <<  DISTANCE4 << " inches on map is "
	   <<  miles  << " miles in city." << endl;

     totMiles = totMiles + miles;

          cout <<  endl << "Total walking mileage is  "  
          <<  totMiles  <<  " miles."  << endl;

     return 0 ;			//  Successful completion
}

float  RoundToNearestTenth (float floatValue){       
     return  float(int(floatValue * 10.0 + 0.5)) / 10.0;
}


