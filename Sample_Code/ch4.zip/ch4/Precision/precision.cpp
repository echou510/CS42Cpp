#include  <iomanip>		        // for setw( ) and setprecision( )
#include  <iostream>

using  namespace  std;

int main (void){
    float   myNumber  =  123.4587 ;

    cout  <<  fixed  <<   showpoint  ; 	// use decimal format
	           				// print decimal points

    cout  <<  "Number is "  <<  setprecision(3)   
              <<  myNumber     <<  endl ;

    return  0 ;
}
