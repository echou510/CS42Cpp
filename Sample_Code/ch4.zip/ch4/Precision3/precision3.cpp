#include  <iomanip>		          // for setw( ) and setprecision( )
#include  <iostream>

using  namespace  std;

int  main(void)
{
    float myNumber    =  123.4 ;
    float yourNumber  =  3.14159 ;

    cout << fixed << showpoint;   // use decimal format
	               				  // print decimal points

    cout << "Numbers are: " << setprecision(4) << endl 
         << setw(10)        << myNumber        << endl
	     << setw(10)        << yourNumber      << endl;

    return 0 ;
}
