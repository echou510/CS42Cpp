#include <iostream>

using namespace std; 

void  DisplayMessage ( int  n ) ;	        // declares function

int main(void){    
      DisplayMessage( 15 ) ;	       //function call
              
      cout  <<  "Good Bye"  <<    endl ;	 
		 
        return 0 ;
}
					// header and body here

void  DisplayMessage (int  n){
      cout  <<  "I have liked math for  "  
                <<  n  <<  " years"  << endl ;
}

