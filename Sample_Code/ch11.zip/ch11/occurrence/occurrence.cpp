// Program counts frequency of each alphabetic character in text file.
#include  <fstream>
#include  <iostream>
#include <cstdlib>
#include  <cctype>
#include <iomanip>
using namespace std; 
	
const int SIZE=91;
void  PrintOccurrences ( const  int [  ] ) ;       // prototype 

int main(int argc, char *arvv[]){
     ifstream dataFile ;
     int        freqCount [SIZE ] ;
     char       ch ;
	 char       index;
		
     dataFile.open ( "usdeclar.txt" ) ;	   // open and verify success
     if  (!dataFile){
            cout  <<  " CAN�T OPEN INPUT FILE ! " << endl;
            return  1;
      }

     for (int  m = 0; m < SIZE;  m++)	// zero out the array
	          freqCount [ m ]  =  0 ;
     				// read file one character at a time

     dataFile.get(ch);		// priming read
     while(dataFile)		// while last read was successful
      {
		 if (isalpha(ch))
		{	
			if (islower(ch))
				ch  =  toupper (ch) ;
			
			freqCount [ ch ]  =  freqCount [ ch ] + 1 ;
		}
		dataFile. get ( ch ) ; 		// get next character
	 }
	PrintOccurrences ( freqCount ) ;
	return  0;
}



// Prints each alphabet character and its frequency
// Precondition:
//	freqCount [ �A� . . �Z� ] are assigned
// Postcondition:
//	freqCount [ �A� . . �Z� ] have been printed
void  PrintOccurrences ( /* in */  const  int  freqCount  [  ] ) {
	char  index ;	
	cout  <<  "File contained "  << endl ;
	cout  <<  "LETTER      OCCURRENCES"  << endl ;
	for   (  index = 'A'  ;  index <= 'Z' ;  index ++ ){
     		cout << setw(4) << index  <<  setw(10)  
		        << freqCount [ index ]  << endl ;
	}
}
