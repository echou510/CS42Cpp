#include <iomanip>
#include <iostream>
using  namespace  std ;

void  Obtain ( int [ ], int ) ; 	                          // prototypes here 
void  FindWarmest ( const  int[ ],  int , int & ) ;
void  FindAverage  ( const  int[ ],  int , int & ) ;
void  Print ( const  int [ ], int ) ;

// Has user enter number temperature values at keyboard
// Precondition:
//    number is assigned  &&  number > 0
// Postcondition:
//    temp [ 0 . . number -1 ]  are assigned
void Obtain ( /*out*/ int  temp[], /*in*/ int number){
      int  m;

      for ( m = 0 ; m < number;  m++ ){
           cout << "Enter a temperature : " ;
           cin >>  temp [m] ;
       }
}

// Prints number  temperature values to screen
// Precondition:
//    number is assigned  &&  number > 0
//    temp [0 . . number -1 ] are assigned
// Postcondition:
//    temp [ 0 . . number -1 ]  have been printed 5 to a line
void Print(/*in*/ const int temp[], /*in*/ int number){
      int  m;
      cout  <<   "You entered: " ;
      for ( m = 0 ; m < number;  m++ ){   
           if  ( m % 5 == 0 ) cout  <<  endl ;
   	       cout  <<  setw(7) << temp [m] ;
   	       
        }
}

// Determines average of temp[0 . . number-1]
// Precondition:
//        number is assigned  &&  number > 0
//        temp [0 . . number -1 ] are assigned
// Postcondition:
//        avg == arithmetic average of temp[0 . . number-1]
void  FindAverage(/*in*/ const int temp[], /*in*/ int number, /*out*/ int &avg){
      int  m;
      int  total = 0;
      for ( m = 0 ; m < number;  m++ )
        {   
           total = total + temp [m] ;
        }
      avg = int (float (total) / float (number) + .5) ;
} // avg = total/number

// Determines largest of temp[0 . . number-1]
// Precondition:
//        number is assigned  &&  number > 0
//        temp [0 . . number -1 ] are assigned
// Postcondition:
//        largest== largest value in temp[0 . . number-1]
void  FindWarmest(/*in*/ const int temp[], /*in*/ int number, /*out*/  int &largest ){
      int  m;
      largest = temp[0] ;      // initialize largest to first element
			            // then compare with other elements
      for ( m = 0 ; m < number;  m++ )
        {   
           if ( temp [m]  > largest )
                largest  =  temp[m] ;
        }
}

int main (int argc, char *args[]){
     int    temp[31] ;	 // array to hold up to 31 temperatures
     int    numDays=3;
     int    average ;
     int    hottest ;
    
     Obtain(temp, numDays);
     Print(temp, numDays);
     cout << endl; 
     
     FindAverage(temp, numDays, average);      
	 FindWarmest(temp, numDays, hottest); 
	 cout << "Average Temp=" << average << "  Hottest Temp=" << hottest << endl; 
     return 0; 
}


