// C++ code to demonstrate working of
// front() and back()
#include<iostream>
#include<array> // for front() and back()
using namespace std;
int main()
{
    // Initializing the array elements
    array<int,6> ar = {1, 2, 3, 4, 5, 6};
    // Printing first element of array
    cout << "First element of array is : ";
    cout << ar.front() << endl;
    // Printing last element of array
    cout << "Last element of array is : ";
    cout << ar.back() << endl;
    return 0;
}


