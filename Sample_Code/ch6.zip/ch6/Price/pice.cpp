#include <iostream>		// for cout
#include <fstream>		// for file I/O

using namespace std;

int  main (void)
{       
       float       price ; 		// declarations
       char        kind ;
       ifstream    myInfile ;
       float       total  =  0.0 ;
       int         count  = 1;
       myInfile.open("myIn.dat") ;

	   // count-controlled processing loop
       while (  count <= 20 ){     
            myInfile   >>  price  >>  kind ;
	        total = total + price ; 
	        count ++ ;
       }
       cout << "Total is: " << total << endl ;
       myInfile.close(  ) ;
       return 0 ;
}       
