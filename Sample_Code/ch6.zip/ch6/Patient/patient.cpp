#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;
int main(void){
     int patientCount;	   	 // declarations
	 int thisID;
	 int howMany;
	 int thisBP;
	 int totalForPatient;
	 int count;
	 float average;
	 ifstream  myInfile;
     myInfile.open("BP.dat");
	 if  (!myInfile) 	// opening failed
	 {        
	    cout << "File opening error. Program terminated.";        
		return  1;
	 }
	 cout << "ID Number      Average BP" << endl;
	 patientCount = 0;
	 myInfile >> thisID >> howMany; // priming read
	 
    while (myInfile)		        // last read successful
    {  
	   //cout << thisID << " " << howMany << endl; 
       patientCount++;
	   cout << setw(9) << thisID;
	   totalForPatient = 0;             // initialize inner loop
       count = 0;
       while (count < howMany){
         myInfile >> thisBP;
         count ++;
         totalForPatient = totalForPatient  + thisBP;
       }

       average = totalForPatient / float(howMany);
       cout  << setw(15) <<  int (average + .5) << endl;             // round
       myInfile  >> thisID  >>  howMany;    // another read
    }
    cout << "There were " << patientCount 
		 << " patients on file." << endl;

	cout << "Program terminated.\n";
    return 0;
}


