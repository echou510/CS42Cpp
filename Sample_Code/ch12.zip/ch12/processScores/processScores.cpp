/* processScores.cpp */
#include <iostream>              // cin, cout, ...
#include <fstream>                // ifstream, ...
#include <string>                   // string
#include <cassert>                 // assert()
#include <vector>                  // vector
#include <numeric>              // accumulate()
using namespace std;
                                   // local prototypes
void fillVectors(string inFileName,  vector<string> & nameVec, vector<double> & scoreVec);
double average(const vector<double> & numberVec);
void displayResults(const vector<string> & names, const vector<double> & scores, double theAverage);

int main() {
  cout << "\nTo process the names and scores in an input file,"
       << "\n enter the name of the file: ";
  string inFileName;
  getline(cin, inFileName);
  vector<string> nameVec;
  vector<double> scoreVec;
  fillVectors(inFileName, nameVec, scoreVec);      // input
  double theAverage = average(scoreVec);           // process
  displayResults(nameVec, scoreVec, theAverage );  // output
}

// Definitions of fillVectors(), average(), displayResults() go here
//-- Needs <ifstream>, <cassert>, and <vector> libraries 
void fillVectors(string inFileName, vector<string> & nameVec, vector<double> & scoreVec){
  // open input stream to inFileName
  ifstream fin(inFileName.data());
  assert(fin.is_open());
  string name;                 // input variables
  double score;
  for (;;)                     //Loop:
  {
    fin >> name >> score;      // read name, score
    if (fin.eof()) break;      // if none left, quit
    nameVec.push_back(name);   // append name to nameVec
    scoreVec.push_back(score); // append score to scoreVec
  }
  fin.close();
}

// Needs <vector> and <numeric> libraries 
double average(const vector<double> & numberVec){
  int numValues = numberVec.size();
  if (numValues > 0){
    double sum = accumulate(numberVec.begin(),
           numberVec.end(), 0.0);
    return sum / numValues;
  }
  else{
    cerr << "\n*** Average: vector is empty!\n" << endl;
    return 0.0;
  }
}

// Needs <vector> library
void displayResults(const vector<string> & names, const vector<double> & scores, double theAverage){
  for (int i = 0; i < names.size(); i++)
     cout << names[i] << '\t' << scores[i] << '\t' << scores[i] - theAverage << endl;
}
