#include <iostream>
#include <climits>
using namespace std; 

int main(int argc, char** argv) {
	register int i=0; 
	for (i=0; i<1000; i++){
		cout << i << endl; 
	}
	return 0;
}
