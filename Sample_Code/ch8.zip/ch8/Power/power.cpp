#include <iostream>
using namespace std; 
int Power(int, int); 

int main(int argc, char** argv) {
	cout << "Base=" << 2  << "  Power=" << 4 << " to " << Power(2, 4) << endl;  
	cout << "Base=" << 16 << "  Power=" << 3 << " to " << Power(16, 3)<< endl;  
	return 0;
}

int Power(/* in */ int x,		// Base number
	       /* in */ int n)	    // Power to raise base to
// This function computes x to the n power
// Precondition:
//    x is assigned  &&  n >= 0  &&  (x to the n) <= INT_MAX
// Postcondition:
//    Function value  ==  x to the n power
{
  int result;   	 // Holds intermediate powers of x   
  result = 1;
  while  (n > 0){
   	result = result*x;
	n--;
  }
  return result;
}

