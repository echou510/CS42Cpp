#include <iostream>

using namespace std; 

namespace a {
	
}

namespace b{
}

int main(int argc, char** argv) {
	return 0;
}
