#include <iostream>

using namespace std; 

namespace a {
	char x = 'A'; 
}
namespace b{
	char x = 'B'; 
}

int main(int argc, char** argv) {
	{ // code block 1: namespace a is used. 
	  using namespace a; 
	  cout << "After using a x=" << x << endl;
    }
    
    { // code block 2: namespace b is used. 
    	using namespace b; 
	    cout << "After using b x=" << x << endl; 
	}
	
	{ // code block 1: namespace a is used. 
	  using namespace a; 
	  cout << "After using a x=" << x << endl;
    }
    
	return 0;
}



