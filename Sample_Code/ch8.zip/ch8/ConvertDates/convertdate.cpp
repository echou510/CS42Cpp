// ******************************************************* 
//  ConvertDates program
//  This program reads dates in American form: mm/dd/yyyy
//  from an input file and writes them to an output file 
//  in American, British: dd/mm/yyyy, and ISO: yyyy-mm-dd
//  formats. No data validation is done on the input file.
// *******************************************************

#include <iostream>		// for cout and endl
#include <iomanip>		// for setw
#include <fstream>		// for file I/O
#include <string>		// for string type
#include <cctype>       // for isdigit()

using namespace std;

const bool DEBUG = true; 

void  Get2Digits(ifstream&, string&);  // prototypes
void  GetYear(ifstream&, string&); 
void  OpenForInput( ifstream& );  
void  OpenForOutput( ofstream& ); 
void  Write(ofstream&, string, string, string);

int  main( )
{
     string    month;   // Both digits of month
     string    day;	  	// Both digits of day
     string    year; 	// Four digits of year
     ifstream  dataIn;	// Input file of dates
     ofstream  dataOut; 	// Output file of dates
     
     OpenForInput(dataIn);
     OpenForOutput(dataOut);
					 // Check files 
     if (!dataIn  || !dataOut)
	   return 1;
					 // Write headings
     dataOut << setw(20) << "American Format"
             << setw(20) << "British Format"
             << setw(20) << "ISO Format"  << endl;
     //cout << "I am A" << endl; 
     Get2Digits(dataIn, month) ;	// Priming read 

     while (dataIn) 	// While last read successful
     {
	   Get2Digits(dataIn, day);
	   GetYear(dataIn, year);
	   Write(dataOut, month, day, year);
	   Get2Digits(dataIn, month);  // Read next data
     }
     return  0;  
}

void GetYear(/* inout */ ifstream&  dataIn, /* out */ string& year)
//  Function reads characters from dataIn and returns four digit 
//  characters in the year string.
//  PRECONDITION:   dataIn assigned
// POSTCONDITION:  year  assigned
{
	char  c;		// One digit of the year
    int   count;		// Loop control variable
    year  = "";			// null string to start

	if (dataIn >> c) { 
	   if (DEBUG) cout << c; 
    }
	else return; 
	
    while (count <4){		
		if (isdigit(c)){
		  year += c; 
          count++;  
	    }
		if (count == 4) continue; 
		if (dataIn >> c) {
		   if (DEBUG) cout << c;
	     }
	    else return; 
	}
	if (DEBUG) cout << endl; 
}	

/*
  fin: input file stream 
  data: output string
  
  this function will read two digits from the input stream. 
  only 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 and / are allowed in input stream. 
  if no digits being read before / or end of line, 
*/
void  Get2Digits(ifstream& fin, string& data){
	char c; 
	int count =0; 
	data = "";
	
	if (fin >> c) {
	  if (DEBUG) 
	   cout << c; 
     }
	else return; 

	while (count<3){
		if (isdigit(c)){
		  data += c; 
		  count++; 
	    }
		if (fin >> c) {
		   if (DEBUG) cout << c; 
	     }
	    else return; 
		if (c=='/') count=100;  // stop reading if /
	}
	if (data.length()==0 || data.length()>2) { 
	    cout << "Error in input file!!" << endl; exit(1); 
		}
    if (data.length()==1){
    	data = '0'+data; 
	}
	if (DEBUG) cout << endl << data << endl; 
} 
void  Write(ofstream& fout, string mo, string d, string yr){
        fout << setw(20) << (mo+"/"+d+"/"+yr) 
             << setw(20) << (d+"/"+mo+"/"+yr) 
             << setw(20) << (mo+"-"+d+"-"+yr) << endl;
}

void  OpenForInput(ifstream& fin){
	string filename; 
	bool done = false; 
	while (!done){
 	 cout << "Enter the input file name: " ; 
 	 getline(cin, filename);
     fin.open(filename.c_str() );
     if (fin.good()) done = true; 
   }
} 

void  OpenForOutput(ofstream& fout){
	 string filename; 
 	 cout << "Enter the output file name: " ;  
	 getline(cin, filename);
     fout.open(filename.c_str() );
} 			


