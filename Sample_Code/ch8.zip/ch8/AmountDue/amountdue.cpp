#include  <iostream>
#include  <fstream>
float AmountDue(char, int);    			// prototype
using namespace std;

int main(void)
{    ifstream  myInfile;
     ofstream  myOutfile;
     int       areaCode, Exchange, calls;
     string    phoneNumber; 
     //int       count = 0;
     float     bill;
     char      service;
     myInfile.open("calls.txt"); if (!myInfile.good()) exit(100);
	 myOutfile.open("bills.txt");					// open files
     while (myInfile >> service >> phoneNumber >> calls){
	  bill  =  AmountDue(service, calls) ;   		// function call
	  cout << service << " " << phoneNumber << " " << calls << endl; 
	  myOutfile  <<  phoneNumber << "  "<< bill  << endl; 
     }
     myInfile.close();					// close files
     myOutfile.close(); 
     
     cout << endl; 
	 cout << "Bill:" << endl;
	 
	 string s; 
	 ifstream fin; 
	 fin.open("bills.txt"); if (!fin.good()) exit(100);
	 getline(fin, s);
	 while (fin){
	 	cout << s << endl; 
	 	getline(fin, s);
	 } 
	 fin.close();  
     return 0; 
}

float  AmountDue(char kind, int calls){   // 2 parameters
     float result ;                  	 	  // 1 local variable

     const float UNLIM_RATE = 40.50,
		         LIM_RATE = 19.38,
		              EXTRA = .09 ;
     if (kind =='U')
         result = UNLIM_RATE;
     else if ((kind == 'L') && (calls <= 30))
          result = LIM_RATE;
     else
          result = LIM_RATE + (calls - 30) * EXTRA;
     return result ;
}
