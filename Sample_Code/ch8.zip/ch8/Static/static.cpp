#include <iostream>

using namespace std; 

int myfunction(int a){
	static int n=0; 
	n= n+1; 
	return n*a; 
}

int main(int argc, char** argv) {
    int i=2, j; 
    j= myfunction(i); 
    cout << "First time: j=" << j << endl; 
    j = myfunction(i); 
    cout << "Second time: j=" << j << endl; 
	return 0;
}


