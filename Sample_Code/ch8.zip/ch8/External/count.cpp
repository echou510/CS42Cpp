#include <iostream>
#include "count.h"
using namespace std; 
int count; 

int sum(int a[], int len){
   int s=0; 
   for (int i=0; i<len; i++){
   	  count++; 
   	  s += a[i]; 
   }
   return s;
}


