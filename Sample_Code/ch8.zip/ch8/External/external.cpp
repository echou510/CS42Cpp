#include <iostream>
#include "count.h"

using namespace std; 

int a[]= {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
int main(int argc, char** argv){
	int y = sum(a, 10); 
	cout << "Number of Iterations=" << count << "   " << "Sum(1, 10) =" << y << endl;  
	return 0;
}



