#ifndef COUNT_H
#define COUNT_H
extern int count;             // export to other modules
extern int sum(int *, int);   // export to other modules
#endif 


