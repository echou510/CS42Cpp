#ifndef GET2DIGITS_H
#define GET2DIGITS_H
extern const bool DEBUG; 
void  Get2Digits(std::ifstream&, std::string&);  // prototypes
#endif


