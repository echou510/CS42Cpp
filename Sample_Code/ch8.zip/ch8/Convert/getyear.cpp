#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "getyear.h"
using namespace std; 
void GetYear(std::ifstream&  dataIn, std::string& year)
//  Function reads characters from dataIn and returns four digit 
//  characters in the year string.
//  PRECONDITION:   dataIn assigned
// POSTCONDITION:  year  assigned
{
	char  c;		// One digit of the year
    int   count;		// Loop control variable
    year  = "";			// null string to start

	if (dataIn >> c) { 
	   if (DEBUG) cout << c; 
    }
	else return; 
	
    while (count <4){		
		if (isdigit(c)){
		  year += c; 
          count++;  
	    }
		if (count == 4) continue; 
		if (dataIn >> c) {
		   if (DEBUG) cout << c;
	     }
	    else return; 
	}
	if (DEBUG) cout << endl; 
}	

