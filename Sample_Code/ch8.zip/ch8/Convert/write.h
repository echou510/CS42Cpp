#ifndef WRITE_H
#define WRITE_H
void  Write(std::ofstream&, std::string, std::string, std::string);
#endif


