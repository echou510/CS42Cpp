// ******************************************************* 
//  ConvertDates program
//  This program reads dates in American form: mm/dd/yyyy
//  from an input file and writes them to an output file 
//  in American, British: dd/mm/yyyy, and ISO: yyyy-mm-dd
//  formats. No data validation is done on the input file.
// *******************************************************

#include <iostream>		// for cout and endl
#include <iomanip>		// for setw
#include <fstream>		// for file I/O
#include <string>		// for string type
#include <cctype>       // for isdigit()
#include "convert.h"
#include "getyear.h"
#include "get2digits.h"
#include "getfiles.h"
#include "write.h"

using namespace std;
const bool DEBUG = true; 

int  main( )
{
     string    month;   // Both digits of month
     string    day;	  	// Both digits of day
     string    year; 	// Four digits of year
     ifstream  dataIn;	// Input file of dates
     ofstream  dataOut; 	// Output file of dates

     OpenForInput(dataIn);
     OpenForOutput(dataOut);
					 // Check files 
     if (!dataIn  || !dataOut)
	   return 1;
					 // Write headings
     dataOut << setw(20) << "American Format"
             << setw(20) << "British Format"
             << setw(20) << "ISO Format"  << endl;
     //cout << "I am A" << endl; 
     Get2Digits(dataIn, month) ;	// Priming read 

     while (dataIn) 	// While last read successful
     {
	   Get2Digits(dataIn, day);
	   GetYear(dataIn, year);
	   Write(dataOut, month, day, year);
	   Get2Digits(dataIn, month);  // Read next data
     }
     return  0;  
}


