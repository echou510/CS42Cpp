#ifndef GETFILES_H
#define GETFILES_H
void  OpenForInput(std::ifstream& );  
void  OpenForOutput(std::ofstream& ); 
#endif


