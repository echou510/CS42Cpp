extern const bool DEBUG; 


