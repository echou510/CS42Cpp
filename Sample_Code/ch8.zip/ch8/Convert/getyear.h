#ifndef GETYEAR_H
#define GETYEAR_H
extern const bool DEBUG; 
void GetYear(std::ifstream&, std::string&); 
#endif


