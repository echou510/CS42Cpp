#ifndef AA_H
#define AA_H
int aa(std::ifstream&);
#endif 
