#include <iostream>
#include <fstream>
#include <string>
#include "getfiles.h"
using namespace std; 
void  OpenForInput(std::ifstream& fin){
	string filename; 
	bool done = false; 
	while (!done){
 	 cout << "Enter the input file name: " ; 
 	 getline(cin, filename);
     fin.open(filename.c_str() );
     if (fin.good()) done = true; 
   }
} 

void  OpenForOutput(std::ofstream& fout){
	 string filename; 
 	 cout << "Enter the output file name: " ;  
	 getline(cin, filename);
     fout.open(filename.c_str() );
} 			

