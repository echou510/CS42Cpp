#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "get2digits.h"
using namespace std; 
void  Get2Digits(std::ifstream& fin, std::string& data){
	char c; 
	int count =0; 
	data = "";
	
	if (fin >> c) {
	  if (DEBUG) 
	   cout << c; 
     }
	else return; 

	while (count<3){
		if (isdigit(c)){
		  data += c; 
		  count++; 
	    }
		if (fin >> c) {
		   if (DEBUG) cout << c; 
	     }
	    else return; 
		if (c=='/') count=100;  // stop reading if /
	}
	if (data.length()==0 || data.length()>2) { 
	    cout << "Error in input file!!" << endl; exit(1); 
		}
    if (data.length()==1){
    	data = '0'+data; 
	}
	if (DEBUG) cout << endl << data << endl; 
} 




