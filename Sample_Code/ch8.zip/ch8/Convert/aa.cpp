#include <iostream>
#include <fstream>
#include <string>
#include "aa.h"
using namespace std; 

int aa(std::ifstream &fin){
	string filename; 
	bool done = false; 
	while (!done){
 	 cout << "Enter the input file name: " ; 
 	 getline(cin, filename);
     fin.open(filename.c_str() );
     if (fin.good()) done = true; 
    }
	return 0; 
}
