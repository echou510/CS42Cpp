#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "write.h"
using namespace std; 
void  Write(std::ofstream& fout, std::string mo, std::string d, std::string yr){
        fout << setw(20) << (mo+"/"+d+"/"+yr) 
             << setw(20) << (d+"/"+mo+"/"+yr) 
             << setw(20) << (mo+"-"+d+"-"+yr) << endl;
}
