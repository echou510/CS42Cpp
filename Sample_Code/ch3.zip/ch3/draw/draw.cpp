#include <iostream>
using namespace std; 
void draw(char ch, int length, int width){
    for (int i=0; i<length; i++){
    	for (int j=0; j<width; j++){
    		cout << ch; 
		}
		cout << endl; 
	}	
}

int main(int argc, char** argv) {
	char c = '&'; 
	int l = 4; 
	int w = 6; 
	draw(c, l, w); 	
	return 0;
}



