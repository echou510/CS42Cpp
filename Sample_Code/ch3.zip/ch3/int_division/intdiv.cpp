#include <iostream>

using namespace std; 

int main(int argc, char** argv) {
    int a= 10; 
    int b= 0; 
    
    cout << (a/b) << endl; 
	return 0;
}


