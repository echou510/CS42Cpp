#include <iostream>

using namespace std; 

int main(int argc, char** argv) {
    double a= 10; 
    double b= 0; 
    
    cout << (a/b) << endl; 
	return 0;
}



