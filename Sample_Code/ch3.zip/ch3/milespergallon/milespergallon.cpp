/* This program computes miles per gallon given four amounts 
    for gallons used, and starting and ending mileage.  
 
     Constants:   The gallon amounts for four fillups.
                           The starting mileage.
		           The ending mileage.
    Output (screen)      The calculated miles per gallon.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

#include <iostream>

using namespace std;
const  float  AMT1 = 11.7 ;  	// Number of gallons for fillup 1
const  float  AMT2 = 14.3 ;  	// Number of gallons for fillup 2 
const  float  AMT3 = 12.2 ; 	// Number of gallons for fillup 3 
const  float  AMT4 =   8.5 ;  	// Number of gallons for fillup 4

const  float  START_MILES = 67308.0 ;      // Starting mileage
const  float  END_MILES     = 68750.5 ;      // Ending mileage

int  main(  )
{
	float mpg ;		     // Computed miles per gallon
	
	mpg = (END_MILES - START_MILES) / 
	                  (AMT1 + AMT2 + AMT3 + AMT4) ;
	cout  <<  "For the gallon amounts " << endl ;
	cout  <<  AMT1  <<  ' ' <<  AMT2  <<  ' '
	         <<  AMT3  <<  ' ' <<  AMT4  <<  endl ;
 	cout  <<  "and a starting mileage of  " 
	         << START_MILES  << endl ;

	cout  <<  "and an ending mileage of  " 
	         << END_MILES  << endl ;

	cout  <<  "the mileage per gallon is " << mpg  << endl ;

   	return 0;
}


