#include <iostream>
#include <cstdlib>

using namespace std; 

int main(int argc, char** argv) {
	int  i = 17;
    char c = 'c'; /* ascii value is 99 */
    float sum;

    sum = i + c;
    cout << "Value of sum : " << sum << endl;
	return 0;
}



