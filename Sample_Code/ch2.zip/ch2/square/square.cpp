#include <iostream>

int Square( int );      // declares these two
int Cube( int );	      // value-returning functions
using namespace std ; 

int main( )
{    
    cout << "The square of 27 is "
	   << Square(27) << endl;	// function call
           
    cout << "The cube of 27 is "
         << Cube(27) << endl;       // function call 	 
    return 0;
}

int Square( int n )	
{
      return n * n;
}


int Cube( int n )		
{
     return n * n * n;
}

