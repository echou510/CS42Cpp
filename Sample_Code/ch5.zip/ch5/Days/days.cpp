// program tells how to spend your day

#include <iostream>
using namespace std;

int main(void)
{	int      day;
	char   raining;
		cout << "Enter day (use 1 for Sunday):";
 		cin   >>  day;
		cout << "Is it raining? (Y/N)";
	 	cin   >>  raining;
	 	
	if  ( ( day == 1) || (day == 7) )          // Sat or Sun
		{	if  (raining == 'Y')
				cout << "Read in bed";	
			else
				cout << "Have fun outdoors";	
		}
		else
		{	cout << "Go to class ";
			if  (raining == 'Y')
			  	cout << "Take an umbrella";
		}
	return 0; 
}
    

