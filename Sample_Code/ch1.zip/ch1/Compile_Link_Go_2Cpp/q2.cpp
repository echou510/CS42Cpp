#include "q2.h"
int z = 5;  

int f(){
	return 3; 
}