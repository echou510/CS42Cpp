#include <iostream> 
#include <cstdio>  // stdio.h from c language 
#include <cstdlib> // c language's stdlib.h
#include <ctime>  //  c language's time.h
#include "q2.h"
extern int f(void); 
using namespace std; 

int main(int argc, char *argv[]){
	 srand (time(NULL));
	 int y = f(); 
	 printf("Y=%d\n", y);
	 printf("Z=%d\n", z); 
	 printf("Random = %d\n", rand()%20);
	return 0; 
}