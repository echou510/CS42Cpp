#ifndef Q2_H
#define Q2_H
extern int z; 
int f(void); 
#endif 