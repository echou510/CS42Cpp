#include <iostream>

using namespace std; 

int main(){
	int i=0; 
	int j=1; 
	cout << i << "+" << j << "="<<(i+j) << endl; 
	return 0;  // 0 for no error, 1 for error
}