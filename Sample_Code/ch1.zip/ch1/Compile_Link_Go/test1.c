#include <stdio.h>

int main(){
	printf("Welcome to C Programming %d\n", 2018); 
	return 0; 
}