#include <stdio.h>
#include "p2.h"
extern int z; 
extern int f(void); 

int main(){
	int y = f(); 
	printf("Number = %d \n", y); 
	printf("Z = %d \n", z); 
	return 0; 
}