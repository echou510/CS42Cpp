#ifndef P2_H
#define P2_H
extern z; 
int f(void); 
#endif 