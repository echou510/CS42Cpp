#include "p2.h"
int z = 5;  // static 

int f(){
	return 3; 
}