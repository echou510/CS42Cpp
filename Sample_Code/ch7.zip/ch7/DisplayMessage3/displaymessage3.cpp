#include  <iostream>

void  DisplayMessage(int); 		    // prototype

using namespace std;

int  main(void){			        // argument
      DisplayMessage(15);			// function call
      cout  <<  "Good Bye"  <<    endl;	 
        return 0;
}
void  DisplayMessage(int  n){
      cout  << "I have liked math for  "  
            << n << " years"  << endl;

     return ;
}

