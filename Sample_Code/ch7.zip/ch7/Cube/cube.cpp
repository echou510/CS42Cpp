#include <iostream>

int Cube(int);				// prototype
using namespace std; 

int Cube (int x){
   return x*x*x; 
}

int main(void){  
   int yourNumber;       // arguments
   int myNumber;
   yourNumber = 14;
   myNumber    =   9 ;
   cout << "My Number = " << myNumber ;
   cout << "its cube is " << Cube (myNumber) << endl ;
 
   cout << "Your Number = " << yourNumber ;
   cout << "its cube is " << Cube (yourNumber) << endl ;
   return 0;  
}


