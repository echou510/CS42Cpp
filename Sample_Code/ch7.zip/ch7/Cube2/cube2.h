#ifndef CUBE2_H
#define CUBE2_H
int  Square (int);		     	 	      // prototypes
int  Cube (int);
#endif 


