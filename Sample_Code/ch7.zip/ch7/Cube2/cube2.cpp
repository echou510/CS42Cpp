#include <iostream>
#include "cube2.h"
using namespace std;
int  main(void){    
      cout  <<  "The square of 27 is "
	        << Square(27) << endl;	      // function call
      cout  << "The cube of 27 is "
            <<  Cube(27) << endl;	      // function call 	 
     return 0;
}
int Square(int n){		// header and body
      return   n * n;
}
int Cube(int  n){		// header and body
     return  n * n * n;
}




