#include <iostream>
#include "rating.h"
using namespace std;
int main(void)
{   char rating;				
    rating = 'X';
	GetRating(rating);		// call
	cout << "That was rating = "
		  << rating << endl;
	return 0;
}
void GetRating (char& letter)
{		cout << "Enter employee rating." << endl;
	    cout << "Use E, G, A, or P : " ;
   		cin >> letter;
   		while ((letter != 'E')  &&  (letter != 'G') && (letter != 'A') && (letter != 'P')){
		  cout << "Rating invalid.  Enter again: ";
		  cin  >> letter;
		}
}


