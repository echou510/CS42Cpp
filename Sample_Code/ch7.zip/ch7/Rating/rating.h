#ifndef RATING_H
#define RATING
void  GetRating(char&);      // prototype
#endif
