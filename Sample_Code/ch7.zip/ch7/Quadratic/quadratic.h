#ifndef QUADRATIC_H
#define QUADRATIC_H
void GetRoots(float, float, float, float&, float&);
#endif
