#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include "quadratic.h"

using namespace std;					
int main(void){	  
      ifstream myInfile;
	  ofstream myOutfile;
	  float a, b, c, first, second; 		    	
	  myInfile.open("q.dat");			   // open files
	  myOutfile.open("qout.dat");
	  while (myInfile >> a >> b >> c){
		  GetRoots(a, b, c, first, second);  //call
		  myOutfile << setw(10) << a 
		            << setw(10) << b 
					<< setw(10) << c 
					<< setw(10) << first 
					<< setw(10) << second << endl;
	  }	 					   // close files
      myInfile.close(); 
      myOutfile.close(); 
      return 0; 
}
void GetRoots( float a,  float b,  float c, float& root1, float& root2){
    float temp;			   // local variable
    temp = b * b - 4.0 * a * c;
    root1 = (-b + sqrt(temp) ) / ( 2.0 * a );
    root2 = (-b - sqrt(temp) ) / ( 2.0 * a ); 
    return;
   }


