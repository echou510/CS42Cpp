#include<iostream>
using namespace std; 

union Employee{
    int Id;
    char Name[25];
    int Age;
    long Salary;
};

int main(int argc, char *argv[]){
    Employee E;

    cout << "\nEnter Employee Id : ";
    cin >> E.Id;

    cout << "\nEnter Employee Name : ";
    scanf("%s", &E.Name); 
    string empty;  // consume the /n mark.
    getline(cin, empty); 

    cout << "\nEnter Employee Age : ";
    cin >> E.Age;

    cout << "\nEnter Employee Salary : ";
    cin >> E.Salary;

    cout << "\n\nEmployee Id : " << E.Id;
    cout << "\nEmployee Name : " << E.Name;
    cout << "\nEmployee Age : " << E.Age;
    cout << "\nEmployee Salary : " << E.Salary;	
    return 0; 
}


