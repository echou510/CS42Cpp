#include <iostream>
#include <cstdlib>
#include <string>
#include <ctime>

using namespace std; 

enum  HealthType  { Poor,  Fair,  Good,  Excellent } ;

struct  AnimalType		// declares a  struct data type
{					//  does not allocate memory
	long             id;
	string           name;
	string           genus;
	string           species;        		          
	string           country;                                   
	int              age;           
	float            weight;          
	HealthType  health;
} ;

AnimalType    thisAnimal ;	 // declare  variables of AnimalType
AnimalType    anotherAnimal ;    

void WriteWord(HealthType h){
	string a; 
    switch(h){
      case Poor  :    cout    << "Poor\n";   break;
      case Fair  :    cout    << "Fair\n";   break;
      case Good  :    cout    << "Good\n";   break;
      case Excellent: cout << "Excellent\n";    break;
	  default:        cout << "Unknown\n";  
    }
}
void  WriteOut(AnimalType);
AnimalType GetAnimalData(){
	/* initialize random seed: */
    srand (time(NULL));
    
	AnimalType a; 
    a.id = rand() % RAND_MAX + 1;
	cout << endl; 
	cout << "Enter the Name of the Animal: " ; 
    cin  >>  a.name;
    cout << "Enter the Genus of the Animal: " ; 
    cin  >>  a.genus;
    a.genus[0] = toupper(a.genus[0]);
	cout << "Enter the Age of the Animal: " ; 
    cin  >>  a.age;
    cout << "Enter the Weight of the Animal: " ; 
    cin  >>  a.weight;

	cout << "Enter the Country of the Animal: " ; 
    cin  >>  a.country;
    cout << "Enter the Species of the Animal: " ; 
    cin  >>  a.species;
    
    string h;
 	cout << "Enter the Health Condition of the Animal(Poor/Fair/Good/Excellent): " ; 
    cin  >>  h;   
    
    if (h.compare("Poor")==0)      a.health = Poor; 
    if (h.compare("Fair")==0)      a.health = Fair; 
	if (h.compare("Good")==0)      a.health = Good; 
	if (h.compare("Excellent")==0) a.health = Excellent;       
	return a; 
}

void ChangeWeightAndAge(AnimalType &a){
	cout << endl; 
	cout << "Enter the New Age of the Animal: " ; 
    cin  >>  a.age;
    cout << "Enter the New Weight of the Animal: " ; 
    cin  >>  a.weight;
}

void  WriteOut(AnimalType thisAnimal){
	 cout   <<  endl; 
	 cout   <<  "ID # "  <<  thisAnimal.id  <<  "  " << thisAnimal.name  << endl ;
	 cout   <<  thisAnimal.genus   <<  thisAnimal.species << endl ;
	 cout   <<  thisAnimal.country << endl ;
     cout   <<  thisAnimal.age   << " years "  << endl ;
	 cout   <<  thisAnimal.weight << " lbs. "  << endl ;
	 cout   << "General health : " ; 
     WriteWord ( thisAnimal.health ) ;
}	

int main(int argc, char** argv) {
	thisAnimal.age  =  18;
    thisAnimal.id   =  2037581;
    cout << "Enter the Weight of the Animal: " ; 
    cin  >>  thisAnimal.weight;
    getline (cin, thisAnimal.species);   // consume the \n from the previous input's feedthrough
    cout << "Enter the Animal's Species: "; 
    getline (cin, thisAnimal.species);
    thisAnimal.name = "giant panda";
    thisAnimal.country = "China"; 
    thisAnimal.genus[0] = toupper(thisAnimal.genus[0]);
    thisAnimal.age++;
    
    anotherAnimal = thisAnimal;  	    // assignment
    cout << "Example of value parameter" << endl; 
    WriteOut(thisAnimal); 			    // value parameter
    ChangeWeightAndAge(thisAnimal);     // reference parameter 
    thisAnimal = GetAnimalData();       // return value of function 
    
    WriteOut(thisAnimal); 			    // value parameter   
	return 0;
}
