#include <iostream>
using namespace std; 

 struct block {            // structure type
  int buf[80];           // data member
  char *pheap;           // data member
  void header(const char *);    // member function
 };

 block data = { {1,2,3}, "basic" };  // structure variable
 block *ps = &data;          // structure pointer

void block::header(const char *st){ // definition of member function for struct block
	cout << st << endl; 
}

int main(int argc, char** argv) {
	 
	 data.pheap++;            // increment data member
	 cout << data.pheap << endl; 
     data.header("magic");        // call member function
     ps->pheap++;             // increment data member
     cout << data.pheap << endl; 
     ps->header("magic");         // call member function
     //ps.pheap++;             // illegal, ps is a pointer
    //data->header("magic");        // illegal, data is a structure
	return 0;
}


